﻿namespace DeckOfCards
{
    public class Card
    {
        readonly public int value;
        readonly public Suites suite;

        public Card(int value, Suites suite)
        {
            this.value = value;
            this.suite = suite;
        }
    }
}
