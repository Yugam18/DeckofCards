﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeckOfCards
{
    public class CardDeck :ICardDeck
    {
        List<Card> cards = new List<Card>();
        int cardsInOneSuit = 13;

        public CardDeck()
        {
            FillDeck();
        }

        private void FillDeck()
        {
            var countOfSuits = Enum.GetNames(typeof(Suites)).Length;

            for (Int32 i = 0; i < countOfSuits; i++)
            {
                int temp = cardsInOneSuit;
                int start = 1;
                while (temp > 0)
                {
                    Card card = new Card(start, (Suites)i);
                    cards.Add(card);
                    start++;
                    temp--;
                }
            }
        }

        public List<Card> GetNewDeck()
        {
            cards = new List<Card>();
            FillDeck();
            return cards;
        }


    }
}
