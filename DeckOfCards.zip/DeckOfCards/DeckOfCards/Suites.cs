﻿namespace DeckOfCards
{
    public enum Suites
    {
        Clubs,
        Hearts,
        Spades,
        Diamond
    }
}
