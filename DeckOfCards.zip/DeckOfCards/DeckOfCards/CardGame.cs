﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeckOfCards
{
    public class CardGame
    {
        readonly ICardDeck _icardDeck;
        private static Random r = new Random();
        public CardGame(ICardDeck cardDeck)
        {
            _icardDeck = cardDeck;
        }

        List<Card> cards;

        public void StartGame()
        {
            cards = _icardDeck.GetNewDeck();
            ShuffleDeck();
        }

        public void PlayCard()
        {
            if (cards.Count == 0)
            {
                Console.WriteLine("No Cards left to play");
                return;
            }
            Console.WriteLine("Card played is: " + cards[0].value + " of " + cards[0].suite);
            cards.RemoveAt(0);
        }

        public void ShuffleDeck()
        {
            if (cards.Count == 0)
            {
                Console.WriteLine("No Cards to shuffle");
                return;
            }
            for (int i = 0; i < cards.Count; i++)
            {
                int idx = r.Next(i, cards.Count);
                var temp = cards[idx];
                cards[idx] = cards[i];
                cards[i] = temp;
            }
        }

        public void RestartGame()
        {
            cards = _icardDeck.GetNewDeck();
        }
    }
}
