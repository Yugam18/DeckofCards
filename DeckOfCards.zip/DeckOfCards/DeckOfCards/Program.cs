﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeckOfCards
{
    class Program
    {
        static void Main(string[] args)
        {
            CardDeck cardDeck = new CardDeck();

            CardGame cardGame = new CardGame(cardDeck);

            cardGame.StartGame();

            cardGame.PlayCard();

            Console.Read();
        }
    }
}
